<?php
use yii\test\ActiveFixture;
class ProjectFixture extends ActiveFixture
{
    public $modelClass = 'app\models\Project';
}