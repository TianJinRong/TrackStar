<?php
namespace tests\codeception\unit;
use app\models\Issue;
use yii\db\ActiveQuery;
use yii\codeception\DbTestCase;
class IssueTest extends DbTestCase
{
    protected function setUp()
    {
    }

    protected function tearDown()
    {
    }

    // tests
    public function testMe()
    {
    }
	
	// 测试获取issue的类型方法
    public function testGetTypes()
    {
		$issue = new Issue();
		$options = $issue->typeOptions;
		$this->assertTrue(is_array($options));
    }

}