<?php
namespace tests\codeception\fixtures;
use yii\test\ActiveFixture;
class ProjectFixture extends ActiveFixture
{
    public $modelClass = 'app\models\Project';
}